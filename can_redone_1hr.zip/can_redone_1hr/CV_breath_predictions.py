import numpy as np
import os
import time
import matplotlib.pyplot as plt
from sklearn import preprocessing
import itertools
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import train_test_split
from numpy import genfromtxt
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.externals import joblib
from sklearn.model_selection import LeaveOneOut, StratifiedKFold
from sklearn.neighbors import NearestNeighbors, KNeighborsClassifier
from keras.utils import np_utils
from keras.layers import Dense, Dropout, BatchNormalization, Conv1D, MaxPooling1D, UpSampling1D, Input, Flatten, Conv2D, MaxPooling2D
from keras.models import Sequential
from keras.optimizers import Adam
from keras import regularizers
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from keras.layers.recurrent import LSTM, SimpleRNN
from keras.optimizers import RMSprop
from perform_curve_representations import DW_transform, AE_transform, conv_AE_transform
from keras import backend as K


def preprocess( X_train, X_test, prep, rep ):

	### Preprocessing method 1 (Squish all values to between 0 and 1, but preserve differences in BL and amplitude)
	if prep == 1:
		X_test = ( X_test - np.min(X_train) )
		X_train = ( X_train - np.min(X_train) )

		X_test = X_test / np.max(X_train)
		X_train = X_train / np.max(X_train)


	### Preprocessing method 2 (Normalize each curve to between 0 and 1)
	if prep == 2:
		for i in range(X_train.shape[0]):
			X_train[i,:] = X_train[i,:] - X_train[i,0]
			X_train[i,:] = X_train[i,:] / np.max(X_train[i,:])

		for i in range(X_test.shape[0]):
			X_test[i,:] = X_test[i,:] - X_test[i,0]
			X_test[i,:] = X_test[i,:] / np.max(X_test[i,:])


	### Preprocessing method 3 (BL subtract each curve))
	if prep == 3:
		for i in range(X_train.shape[0]):
			X_train[i,:] = X_train[i,:] - X_train[i,0]

		for i in range(X_test.shape[0]):
			X_test[i,:] = X_test[i,:] - X_test[i,0]


	### Preprocessing method 4 (Z normalize each curve)
	if prep == 4:
		for i in range(X_train.shape[0]):
			mean = np.mean(X_train[i,:])
			stdev = np.std(  X_train[i,:] )
			X_train[i,:] = ( X_train[i,:] - mean ) / stdev

		for i in range(X_test.shape[0]):
			mean = np.mean(X_test[i,:])
			stdev = np.std(  X_test[i,:] )
			X_test[i,:] = ( X_test[i,:] - mean ) / stdev

	if prep == 5:
		pca1 = PCA(n_components = 2)
		pca1.fit(X_train)
		X_train = pca1.transform(X_train)
		X_test = pca1.transform(X_test)

	if prep == 6:
		pca1 = PCA(n_components = 2, whiten = True)
		pca1.fit(X_train)
		X_train = pca1.transform(X_train)
		X_test = pca1.transform(X_test)


	if prep == 7: # Same as one, but make the mean of the whole dataset zero

		X_test = ( X_test - np.min(X_train) )
		X_train = ( X_train - np.min(X_train) )

		X_test = X_test / np.max(X_train)
		X_train = X_train / np.max(X_train)

		X_test = ( X_test - np.mean(X_train) )
		X_train = ( X_train - np.mean(X_train) )


	if rep == 'AE':
		X_train_enc, X_test_enc = AE_transform(X_train, X_test, data, prep)

	if rep == 'conv_AE':
		X_train_enc, X_test_enc = conv_AE_transform(X_train, X_test, data, prep)

	if rep == 'DWT':
		X_train_enc, X_test_enc = DW_transform(X_train, X_test, data, prep)

	if rep == 'raw':
			X_train_enc = X_train
			X_test_enc = X_test


	return X_train_enc, X_test_enc

def initializeClassifier(algorithm, x_train, params):
	if algorithm == 'ANN':
		classifier = Sequential()
		layers = params[0]
		learnRate = params[1]
		activation = params[2]
		dropout = params[3]
		l2 = params[4]

		for j in range(len(layers)):
			if j == 0:
				classifier.add(Dense(layers[j], input_shape = (x_train.shape[1],),activation = activation,kernel_regularizer = regularizers.l2(l2)))
			else:
				classifier.add(Dense(layers[j],activation = activation, kernel_regularizer = regularizers.l2(l2)))
		classifier.add(Dense(2, activation = 'softmax'))

		adam = Adam(lr=learnRate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.001)
		classifier.compile(loss = 'binary_crossentropy', optimizer = adam, metrics = ['accuracy'])


	if algorithm == 'SVM':
		classifier = SVC( kernel='rbf', C = params[0], gamma = params[1] )

	return classifier


def initializeFCN(x_train, params):
	classifier = Sequential()
	layers = params[0]
	learnRate = params[1]
	dropout = params[2]
	l2 = params[3]

	for j in range(len(layers)):
		if j == 0:
			classifier.add(Conv1D(layers[j], input_shape = (x_train.shape[1],4), activation = activation, kernel_regularizer = regularizers.l2(l2), padding = 'valid'))
			classifier.add( MaxPooling1D(3) )
		else:
			classifier.add(Conv1D(layers[j],activation = activation, kernel_regularizer = regularizers.l2(l2)))
			classifier.add( MaxPooling1D(3) )


	classifier.add(Dense(32, activation = 'relu'))
	classifier.add(Dense(32, activation = 'relu'))
	classifier.add(Dense(2, activation = 'softmax'))

	adam = Adam(lr=learnRate, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.001)
	classifier.compile(loss = 'binary_crossentropy', optimizer = adam, metrics = ['accuracy'])

	return classifier



# def initializeFCN(x_train):
# 	input_dim = x_train.shape[1]

# 	dummy = np.zeros((50,200,4))

# 	classifier = Sequential()
# 	classifier.add( Conv1D(32, 64, input_shape= (input_dim,4), activation = 'relu', padding = 'valid') )
# 	# classifier.add( BatchNormalization() )
# 	# print(classifier.predict(dummy).shape)
# 	classifier.add( MaxPooling1D(3) )
# 	# print(classifier.predict(dummy).shape)
# 	classifier.add( Conv1D(32, 32, activation = 'relu', padding = 'valid') )
# 	# classifier.add( BatchNormalization() )
# 	# print(classifier.predict(dummy).shape)
# 	classifier.add( MaxPooling1D(3) )
# 	# classifier.add( Conv1D(32, 8, activation = 'relu', padding = 'valid') )
# 	# classifier.add( BatchNormalization() )
# 	# print(classifier.predict(dummy).shape)
# 	# classifier.add( MaxPooling1D(3) )
# 	# print(classifier.predict(dummy).shape)
# 	classifier.add( Flatten() )
# 	# classifier.add(Dense(500, activation = 'relu'))
# 	classifier.add( Dense(64, activation = 'relu'))
# 	# classifier.add( Dropout(0))
# 	classifier.add( Dense(4, activation = 'relu'))
# 	# classifier.add( Dropout(0.25))
# 	# classifier.add(Dense(500, activation = 'relu'))
# 	classifier.add( Dense(2, activation = 'softmax'))

# 	adam = Adam(lr=0.001, beta_1=0.9, beta_2=0.999, epsilon=1e-08, decay=0.001)
# 	classifier.compile(loss = 'binary_crossentropy', optimizer = adam, metrics = ['accuracy'])

# 	return classifier

def featureProcessing(train, test):
	scaler = preprocessing.StandardScaler().fit(train)
	train = scaler.transform(train)
	test = scaler.transform(test)

	return train, test

# Load data
X_train_1 = np.transpose( genfromtxt('../April 2019 breath/stacked1.csv', delimiter=',') )
X_train_2 = np.transpose( genfromtxt('../April 2019 breath/stacked2.csv', delimiter=',') )
X_train_3 = np.transpose( genfromtxt('../April 2019 breath/stacked3.csv', delimiter=',') )
X_train_4 = np.transpose( genfromtxt('../April 2019 breath/stacked4.csv', delimiter=',') )

X = np.hstack((X_train_1, X_train_2, X_train_3, X_train_4))
Y = genfromtxt('../April 2019 breath/targets_binary.csv', delimiter=',')
Y_enc = np_utils.to_categorical(Y)



##### Change these parameters
preprocess_method_list = [4]
representation_method_list = ['raw']
standard_scale_features = False
alg = 'SVM'
#####



#KNN params
KNNParamList = [1]

#CNN params
layers = [[8],[32],[64]]
learnRate = [0.001]
activation = ['relu']
dropout = [0,0.25]
l2 = [0,0.00001,0.0001]
CNNParamList = list( itertools.product(layers,learnRate,activation,dropout,l2) )

# ANN params
layers = [[64]]
learnRate = [0.001]
activation = ['relu']
dropout = [0,0.25]
l2 = [0,0.00001,0.0001]
ANNParamList = list( itertools.product(layers,learnRate,activation,dropout,l2) )

# SVM params
cList = [0.1,1,10,100,1000,10000]
gammaList = [0.0001,0.001,0.01,0.1,1]
SVMParamList = list( itertools.product( cList,gammaList ) )

if alg == 'SVM':
	ParamList = SVMParamList

if alg == 'KNN':
	ParamList = KNNParamList

if alg == 'ANN':
	ParamList = ANNParamList

if alg == 'CNN':
	ParamList = CNNParamList


scores = []
loo = LeaveOneOut()
kf = StratifiedKFold(n_splits = 4, shuffle = True, random_state=42)

for prep in preprocess_method_list:
	for rep in representation_method_list:
		for Params in ParamList:
			start_time = time.time()
			k=0
			y_pred = []
			y_actual = []
			# for train_index, test_index in kf.split(X,Y):
			for train_index, test_index in loo.split(X_train_1):
				# if test_index != 2:
				#
				# 	X_train_1, X_test_1 = X_train_1[train_index], X_train_1[test_index]
				# 	X_train_2, X_test_2 = X_train_2[train_index], X_train_2[test_index]
				# 	X_train_3, X_test_3 = X_train_3[train_index], X_train_3[test_index]
				# 	X_train_4, X_test_4 = X_train_4[train_index], X_train_4[test_index]

					if alg == 'KNN':
						Y_train, Y_test = Y[train_index], Y[test_index]

						X_train_1, X_test_1 = preprocess( X_train_1, X_test_1,  prep = prep, rep = rep )
						X_train_2, X_test_2 = preprocess( X_train_2, X_test_2,  prep = prep, rep = rep )
						X_train_3, X_test_3 = preprocess( X_train_3, X_test_3,  prep = prep, rep = rep )
						X_train_4, X_test_4 = preprocess( X_train_4, X_test_4,  prep = prep, rep = rep )

						train = np.hstack((X_train_1,X_train_2,X_train_3,X_train_4))
						test = np.hstack((X_test_1,X_test_2,X_test_3,X_test_4))

						if standard_scale_features == True:
							train, test = featureProcessing(train, test)

						clf = KNeighborsClassifier(n_neighbors = Params, algorithm = 'brute')
						clf.fit(train, Y_train)
						y_pred.extend( clf.predict(test) )
						y_actual.extend( Y[test_index] )

					if alg == 'LDA':
						Y_train, Y_test = Y[train_index], Y[test_index]

						X_train_1, X_test_1 = preprocess( X_train_1, X_test_1, data = data,  prep = prep, rep = rep )
						X_train_2, X_test_2 = preprocess( X_train_2, X_test_2, data = data,  prep = prep, rep = rep )
						X_train_3, X_test_3 = preprocess( X_train_3, X_test_3, data = data,  prep = prep, rep = rep )
						X_train_4, X_test_4 = preprocess( X_train_4, X_test_4, data = data,  prep = prep, rep = rep )

						train = np.hstack((X_train_1,X_train_2,X_train_3,X_train_4))
						test = np.hstack((X_test_1,X_test_2,X_test_3,X_test_4))

						if standard_scale_features == True:
							train, test = featureProcessing(train, test)

						clf = LinearDiscriminantAnalysis()
						clf.fit(train, Y_train)
						y_pred.extend( clf.predict(test) )
						y_actual.extend( Y[test_index] )

					if alg == 'SVM':
						Y_train, Y_test = Y[train_index], Y[test_index]

						X_train_1, X_test_1 = preprocess( X_train_1, X_test_1,  prep = prep, rep = rep )
						X_train_2, X_test_2 = preprocess( X_train_2, X_test_2,  prep = prep, rep = rep )
						X_train_3, X_test_3 = preprocess( X_train_3, X_test_3,  prep = prep, rep = rep )
						X_train_4, X_test_4 = preprocess( X_train_4, X_test_4,  prep = prep, rep = rep )

						train = np.hstack((X_train_1,X_train_2,X_train_3,X_train_4))
						test = np.hstack((X_test_1,X_test_2,X_test_3,X_test_4))

						if standard_scale_features == True:
							train, test = featureProcessing(train, test)

						clf = initializeClassifier('SVM', train, Params)
						clf.fit(train, Y_train)
						# y_pred.append( clf.predict(X_test) )
						y_pred.extend( clf.predict(test) )
						y_actual.extend( Y[test_index] )


					if alg == 'ANN':
						Y_train, Y_test = Y_enc[train_index], Y_enc[test_index]

						X_train_1, X_test_1 = preprocess( X_train_1, X_test_1, data = data,  prep = prep, rep = rep )
						X_train_2, X_test_2 = preprocess( X_train_2, X_test_2, data = data,  prep = prep, rep = rep )
						X_train_3, X_test_3 = preprocess( X_train_3, X_test_3, data = data,  prep = prep, rep = rep )
						X_train_4, X_test_4 = preprocess( X_train_4, X_test_4, data = data,  prep = prep, rep = rep )

						train = np.hstack((X_train_1,X_train_2,X_train_3,X_train_4))
						test = np.hstack((X_test_1,X_test_2,X_test_3,X_test_4))

						if standard_scale_features == True:
							train, test = featureProcessing(train, test)

						clf = initializeClassifier('ANN', train, Params)
						history = clf.fit(train, Y_train, epochs=500, verbose = 0, validation_data = (test,Y_test))

						# if k == 0:
						# 	plt.figure()
						# 	plt.plot(history.history['loss'])
						# 	plt.plot(history.history['acc'])
						# 	plt.plot(history.history['val_acc'])
						# 	plt.show()

						y_pred.extend( clf.predict_classes(test) )
						y_actual.extend( Y[test_index] )


					if alg == 'CNN':
						Y_train, Y_test = Y_enc[train_index], Y_enc[test_index]

						X_train_1, X_test_1 = preprocess( X_train_1, X_test_1, data = data,  prep = prep, rep = rep )
						X_train_2, X_test_2 = preprocess( X_train_2, X_test_2, data = data,  prep = prep, rep = rep )
						X_train_3, X_test_3 = preprocess( X_train_3, X_test_3, data = data,  prep = prep, rep = rep )
						X_train_4, X_test_4 = preprocess( X_train_4, X_test_4, data = data,  prep = prep, rep = rep )

						X_train_1 = X_train_1.reshape(( X_train_1.shape[0], X_train_1.shape[1], 1 ))
						X_train_2 = X_train_2.reshape(( X_train_2.shape[0], X_train_2.shape[1], 1 ))
						X_train_3 = X_train_3.reshape(( X_train_3.shape[0], X_train_3.shape[1], 1 ))
						X_train_4 = X_train_4.reshape(( X_train_4.shape[0], X_train_4.shape[1], 1 ))
						# print(X_train_1.shape)

						X_test_1 = X_test_1.reshape(( X_test_1.shape[0], X_test_1.shape[1], 1 ))
						X_test_2 = X_test_2.reshape(( X_test_2.shape[0], X_test_2.shape[1], 1 ))
						X_test_3 = X_test_3.reshape(( X_test_3.shape[0], X_test_3.shape[1], 1 ))
						X_test_4 = X_test_4.reshape(( X_test_4.shape[0], X_test_4.shape[1], 1 ))


						train = np.stack((X_train_1,X_train_2,X_train_3,X_train_4), axis=2)
						test = np.stack((X_test_1,X_test_2,X_test_3,X_test_4), axis=2)
						train = train.reshape((train.shape[0], train.shape[1],4))
						test = test.reshape((test.shape[0], test.shape[1],4))

						if k == 0:
							print(train.shape)
							print(test.shape)

						if standard_scale_features == True:
							train, test = featureProcessing(train, test)


						# X_train = X_train.reshape((X_train.shape[0], X_train.shape[1],1))
						# X_test = X_test.reshape((X_test.shape[0], X_test.shape[1],1))

						clf = initializeFCN( train, Params )
						history = clf.fit(train, Y_train, epochs=2000, verbose = 0, validation_data = (test,Y_test))

						if k == 0:
							plt.plot(history.history['loss'])
							plt.plot(history.history['acc'])
							plt.plot(history.history['val_acc'])
							plt.show()

						y_pred.extend( clf.predict_classes(test) )
						y_actual.extend( Y[test_index] )


					k = k+1
					# if k % 5 == 0:
					# 	print(k)

					if K.backend() == 'tensorflow':
						# print('plib')
						K.clear_session()


			q = 0
			for i in range(len(y_actual)):
				if y_actual[i] == y_pred[i]:
					q = q + 1

			scores.append(q / len(y_pred))
			print(q / len(y_pred))
			print(y_pred)

			print('time: ' + str( time.time() - start_time ))


bestScore = np.max(scores)
bestScoreIndex = np.argmax(scores)

if alg == 'SVM':
	bestSVMParams = SVMParamList[bestScoreIndex]
	print("Best results for SVM: %s with %s" % ( bestScore, bestSVMParams ))

if alg == 'RF':
	bestRFParams = RFParamList[bestScoreIndex]
	print("Best results for RF : %s with %s" % ( bestScore, bestRFParams ))

if alg == 'KNN':
	bestKNNParams = KNNParamList[bestScoreIndex]
	print("Best results for KNN: %s with %s" % ( bestScore, bestKNNParams ))

if alg == 'ANN':
	bestScore = np.max(best_Acces)
	bestScores.append(bestScore)
	bestScoreIndex = np.argmax(best_Acces)
	bestANNEpochs = best_epochs[bestScoreIndex]
	bestANNParams = ANNParamList[bestScoreIndex]
	print("Best results for MLP: %s with %s and %s epochs" % (  bestScore, bestANNParams, bestANNEpochs ))
