import numpy as np
import math
import os
from numpy import genfromtxt

R = 10000
V0 = 5

testList = [i for i in range(4,22)]
# testList = [i for i in range(1,2)]

for i in  testList:
	
	current = genfromtxt( str(i) + '.csv', delimiter=',' )
	current = current[0:2999,:] * (4.096/2**15)

	current1 = current[:,1].reshape((current.shape[0],1))
	current2 = current[:,2].reshape((current.shape[0],1))
	current3 = current[:,3].reshape((current.shape[0],1))
	current4 = current[:,4].reshape((current.shape[0],1))
	print(current1)

	desiredTimeBetweenSamples = 1
	timeBetweenSamples = 0.1
	samplingRatio = math.floor(desiredTimeBetweenSamples/timeBetweenSamples)

	### MA filter
	samples = 10
	smoothedData1 = np.zeros((current1.shape[0],current1.shape[1]))
	smoothedData2 = np.zeros((current2.shape[0],current2.shape[1]))
	smoothedData3 = np.zeros((current3.shape[0],current3.shape[1]))
	smoothedData4 = np.zeros((current4.shape[0],current4.shape[1]))

	for j in range(samples, current1.shape[0]-samples):
		sum1 = 0
		sum2 = 0
		sum3 = 0
		sum4 = 0

		for k in range(-1*samples, samples+1):
			sum1 = sum1 + current1[j+k][0]
			sum2 = sum2 + current2[j+k][0]
			sum3 = sum3 + current3[j+k][0]
			sum4 = sum4 + current4[j+k][0]

		smoothedData1[j] = sum1/(2*samples+1)
		smoothedData2[j] = sum2/(2*samples+1)
		smoothedData3[j] = sum3/(2*samples+1)
		smoothedData4[j] = sum4/(2*samples+1)

	for j in range(smoothedData1.shape[0]):
			if smoothedData1[j][0] == 0:
				smoothedData1[j][0] = current1[j][0]
			if smoothedData2[j][0] == 0:
				smoothedData2[j][0] = current2[j][0]
			if smoothedData3[j][0] == 0:
				smoothedData3[j][0] = current3[j][0]
			if smoothedData4[j][0] == 0:
				smoothedData4[j][0] = current4[j][0]

	# Downsample
	downsampledData1 = np.zeros((1,1))
	downsampledData2 = np.zeros((1,1))
	downsampledData3 = np.zeros((1,1))
	downsampledData4 = np.zeros((1,1))

	for j in range(current.shape[0]):
		if (j%samplingRatio == 0):
			if(j == 0):
				downsampledData1[0][0] = np.array([[smoothedData1[j,0]]])
				downsampledData2[0][0] = np.array([[smoothedData2[j,0]]])
				downsampledData3[0][0] = np.array([[smoothedData3[j,0]]])
				downsampledData4[0][0] = np.array([[smoothedData4[j,0]]])
			else:
				downsampledData1 = np.vstack((downsampledData1,np.array([[smoothedData1[j,0]]])))
				downsampledData2 = np.vstack((downsampledData2,np.array([[smoothedData2[j,0]]])))
				downsampledData3 = np.vstack((downsampledData3,np.array([[smoothedData3[j,0]]])))
				downsampledData4 = np.vstack((downsampledData4,np.array([[smoothedData4[j,0]]])))
					

	# Convert from voltage to fractional change in conductance
	for j in range(downsampledData1.shape[0]):
		V = downsampledData1[j][0]
		downsampledData1[j][0] = V/(R*(V0-V))
		V = downsampledData2[j][0]
		downsampledData2[j][0] = V/(R*(V0-V))
		V = downsampledData3[j][0]
		downsampledData3[j][0] = V/(R*(V0-V))
		V = downsampledData4[j][0]
		downsampledData4[j][0] = V/(R*(V0-V))

	baseline = downsampledData1[0][0]
	for j in range(downsampledData1.shape[0]):
		downsampledData1[j][0] = (downsampledData1[j][0] - baseline) / baseline
	baseline = downsampledData2[0][0]
	for j in range(downsampledData2.shape[0]):
		downsampledData2[j][0] = (downsampledData2[j][0] - baseline) / baseline
	baseline = downsampledData3[0][0]
	for j in range(downsampledData3.shape[0]):
		downsampledData3[j][0] = (downsampledData3[j][0] - baseline) / baseline
	baseline = downsampledData4[0][0]
	for j in range(downsampledData4.shape[0]):
		downsampledData4[j][0] = (downsampledData4[j][0] - baseline) / baseline


	if i == testList[0]:
		stacked1 = downsampledData1
		stacked2 = downsampledData2
		stacked3 = downsampledData3
		stacked4 = downsampledData4
	else:
		stacked1 = np.hstack(( stacked1, downsampledData1 ))
		stacked2 = np.hstack(( stacked2, downsampledData2 ))
		stacked3 = np.hstack(( stacked3, downsampledData3 ))
		stacked4 = np.hstack(( stacked4, downsampledData4 ))


new_time = np.array([k for k in range( 0, downsampledData1.shape[0], 1 )])
new_time = new_time.reshape((len(new_time),1))

# stacked1 = np.hstack((new_time,stacked1))
# stacked2 = np.hstack((new_time,stacked2))
# stacked3 = np.hstack((new_time,stacked3))
# stacked4 = np.hstack((new_time,stacked4))

# nplist = np.array(selectedList)
# nplist = nplist.reshape((1,len(nplist)))

# stacked1 = np.vstack((nplist,stacked1))
# stacked2 = np.vstack((nplist,stacked2))
# stacked3 = np.vstack((nplist,stacked3))
# stacked4 = np.vstack((nplist,stacked4))

# print(new_time.shape)
print(stacked1.shape)
print(stacked2.shape)
print(stacked3.shape)
print(stacked4.shape)


np.savetxt(r'stacked1.csv', stacked1, fmt='%.10f', delimiter=',')
np.savetxt(r'stacked2.csv', stacked2, fmt='%.10f', delimiter=',')
np.savetxt(r'stacked3.csv', stacked3, fmt='%.10f', delimiter=',')
np.savetxt(r'stacked4.csv', stacked4, fmt='%.10f', delimiter=',')
