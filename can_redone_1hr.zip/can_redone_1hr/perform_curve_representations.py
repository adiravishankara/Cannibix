import numpy as np
import os
import time
import matplotlib.pyplot as plt
from sklearn import preprocessing
import itertools
from mpl_toolkits.mplot3d import Axes3D
from sklearn.model_selection import train_test_split
from numpy import genfromtxt
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.externals import joblib 
from sklearn.model_selection import LeaveOneOut, StratifiedKFold
from sklearn.neighbors import NearestNeighbors, KNeighborsClassifier
from keras.utils import np_utils
from keras.layers import Dense, Dropout, Conv1D, MaxPooling1D, Flatten
from keras.models import Sequential
from keras.optimizers import Adam
from keras import regularizers
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from keras.layers.recurrent import LSTM, SimpleRNN
from keras.optimizers import RMSprop
import pywt


def DW_transform(X_train, X_test, data, prep):

	coeffs_train = pywt.wavedec(X_train, 'db6', level = 4)
	coeffs_test = pywt.wavedec(X_test, 'db6', level = 4)
	# print(coeffs_test[0])
	# print(coeffs_test[1])



	# coeffs_train[-1] = np.zeros_like(coeffs_train[-1])
	# coeffs_train[-2] = np.zeros_like(coeffs_train[-2])
	# coeffs_train[-3] = np.zeros_like(coeffs_train[-3])
	# coeffs_train[-4] = np.zeros_like(coeffs_train[-4])

	# coeffs_test[-1] = np.zeros_like(coeffs_test[-1])
	# coeffs_test[-2] = np.zeros_like(coeffs_test[-2])
	# coeffs_test[-3] = np.zeros_like(coeffs_test[-3])
	# coeffs_test[-4] = np.zeros_like(coeffs_test[-4])

	# X_train_enc = pywt.waverec(coeffs_train, 'db6')
	# X_test_enc = pywt.waverec(coeffs_test, 'db6')	

	X_train_enc = np.hstack((coeffs_train[0],coeffs_train[1]))
	X_test_enc = np.hstack((coeffs_test[0],coeffs_test[1]))

	if data == 'data_humidity_seperate':

		coeffs_train_humidity = pywt.wavedec(X_train_humidity, 'db6', level = 4)
		coeffs_test_humidity = pywt.wavedec(X_test_humidity, 'db6', level = 4)

		# coeffs_train_humidity[-1] = np.zeros_like(coeffs_train_humidity[-1])
		# coeffs_train_humidity[-2] = np.zeros_like(coeffs_train_humidity[-2])
		# coeffs_train_humidity[-3] = np.zeros_like(coeffs_train_humidity[-3])
		# coeffs_train_humidity[-4] = np.zeros_like(coeffs_train_humidity[-4])

		# coeffs_test_humidity[-1] = np.zeros_like(coeffs_test_humidity[-1])
		# coeffs_test_humidity[-2] = np.zeros_like(coeffs_test_humidity[-2])
		# coeffs_test_humidity[-3] = np.zeros_like(coeffs_test_humidity[-3])
		# coeffs_test_humidity[-4] = np.zeros_like(coeffs_test_humidity[-4])

		# X_train_humidity_enc = pywt.waverec(coeffs_train_humidity, 'db6')
		# X_test_humidity_enc = pywt.waverec(coeffs_test_humidity, 'db6')

		X_train_humidity_enc = coeffs_train_humidity[0]
		X_test_humidity_enc = coeffs_test_humidity[0]

		X_train_enc = np.hstack((X_train_enc, X_train_humidity_enc ))
		X_test_enc = np.hstack((X_test_enc, X_test_humidity_enc ))


	return X_train_enc, X_test_enc


def DF_transform(X_train, X_train_humidity, X_test, X_test_humidity, data, prep):

	return X_trans


def AE_transform(X_train, X_train_humidity, X_test, X_test_humidity, data, prep):
	input_dim = 200

	autoencoder1 = Sequential()
	autoencoder1.add( Dense(128, input_shape= (input_dim,), activation = 'relu') )
	autoencoder1.add( Dense(32, activation = 'relu') )
	autoencoder1.add( Dense(8, activation = 'relu') )
	autoencoder1.add( Dense(32, activation = 'relu') )
	autoencoder1.add( Dense(128, activation = 'relu') )
	if prep == 0 or prep == 3:
		autoencoder1.add( Dense(input_dim, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder1.add( Dense(input_dim, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder1.add( Dense(input_dim, activation = 'linear') )

	autoencoder2 = Sequential()
	autoencoder2.add( Dense(128, input_shape= (input_dim,), activation = 'relu') )
	autoencoder2.add( Dense(32, activation = 'relu') )
	autoencoder2.add( Dense(8, activation = 'relu') )
	autoencoder2.add( Dense(32, activation = 'relu') )
	autoencoder2.add( Dense(128, activation = 'relu') )
	if prep == 0 or prep == 3:
		autoencoder2.add( Dense(input_dim, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder2.add( Dense(input_dim, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder2.add( Dense(input_dim, activation = 'linear') )

	autoencoder3 = Sequential()
	autoencoder3.add( Dense(256, input_shape= (400,), activation = 'relu') )
	autoencoder3.add( Dense(64, activation = 'relu') )
	autoencoder3.add( Dense(16, activation = 'relu') )
	autoencoder3.add( Dense(64, activation = 'relu') )
	autoencoder3.add( Dense(256, activation = 'relu') )
	autoencoder3.add( Dense(400, activation = 'linear') )
	if prep == 0 or prep == 3:
		autoencoder3.add( Dense(400, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder3.add( Dense(400, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder3.add( Dense(400, activation = 'linear') )


	if data != 'data_humidity_together':
		autoencoder1.compile(optimizer='adam', loss = 'mse')
		autoencoder1.fit( X_train, X_train, epochs=500, verbose=0 )

	if data == 'data_humidity_seperate':
		autoencoder2.compile(optimizer='adam', loss = 'mse')
		autoencoder2.fit( X_train_humidity, X_train_humidity, epochs=500, verbose=0 )
		
	if data == 'data_humidity_together':
		autoencoder3.compile(optimizer='adam', loss = 'mse')
		autoencoder3.fit( X_train, X_train, epochs=500, verbose=0 )
		

	encoder1 = Sequential()
	encoder1.add(Dense(128, input_shape = (200,), weights = autoencoder1.layers[0].get_weights(), activation = 'relu'))
	encoder1.add(Dense(32, weights = autoencoder1.layers[1].get_weights(), activation = 'relu'))
	encoder1.add(Dense(8, weights = autoencoder1.layers[2].get_weights(), activation = 'relu'))

	encoder2 = Sequential()
	encoder2.add(Dense(128, input_shape = (200,), weights = autoencoder2.layers[0].get_weights(), activation = 'relu'))
	encoder2.add(Dense(32, weights = autoencoder2.layers[1].get_weights(), activation = 'relu'))
	encoder2.add(Dense(8, weights = autoencoder2.layers[2].get_weights(), activation = 'relu'))

	encoder3 = Sequential()
	encoder3.add(Dense(256, input_shape = (400,), weights = autoencoder3.layers[0].get_weights(), activation = 'relu'))
	encoder3.add(Dense(64, weights = autoencoder3.layers[1].get_weights(), activation = 'relu'))
	encoder3.add(Dense(16, weights = autoencoder3.layers[2].get_weights(), activation = 'relu'))


	if data == 'data_only':
		X_train_enc = encoder1.predict(X_train)
		X_test_enc = encoder1.predict(X_test)

	if data == 'data_humidity_seperate':
		X_train_enc = encoder1.predict(X_train)
		X_test_enc = encoder1.predict(X_test)

		X_train_humidity_enc = encoder2.predict(X_train_humidity)
		X_test_humidity_enc = encoder2.predict(X_test_humidity)

		X_train_enc = np.hstack((X_train_enc,X_train_humidity_enc))
		X_test_enc = np.hstack((X_test_enc,X_test_humidity_enc))

	if data == 'data_humidity_together':
		X_train_enc = encoder3.predict(X_train)
		X_test_enc = encoder3.predict(X_test)


	return X_train_enc, X_test_enc


def conv_AE_transform(X_train, X_train_humidity, X_test, X_test_humidity, data, prep):
	input_dim = 200

	X_train = X_train.reshape((X_train.shape[0], X_train.shape[1],1))
	X_test = X_test.reshape((X_test.shape[0], X_test.shape[1],1))
	X_train_humidity = X_train_humidity.reshape((X_train_humidity.shape[0], X_train_humidity.shape[1],1))
	X_test_humidity = X_test_humidity.reshape((X_test_humidity.shape[0], X_test_humidity.shape[1],1))	

	autoencoder1 = Sequential()
	autoencoder1.add( Conv1D(16, 64, input_shape= (input_dim,1), activation = 'relu', padding = 'same') )
	if prep == 0 or prep == 3:
		autoencoder1.add( Conv1D(1, 1, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder1.add( Conv1D(1, 1, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder1.add( Conv1D(1, 1, activation = 'linear') )


	autoencoder2 = Sequential()
	autoencoder2.add( Conv1D(16, 64, input_shape= (input_dim,1), activation = 'relu', padding = 'same') )
	if prep == 0 or prep == 3:
		autoencoder2.add( Conv1D(1, 1, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder2.add( Conv1D(1, 1, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder2.add( Conv1D(1, 1, activation = 'linear') )


	autoencoder3 = Sequential()
	autoencoder3.add( Conv1D(32, 4, input_shape= (input_dim,1), activation = 'relu', padding = 'same') )	
	if prep == 0 or prep == 3:
		autoencoder3.add( Conv1D(1, 1, activation = 'relu') )
	if prep == 1 or prep == 2:
		autoencoder3.add( Conv1D(1, 1, activation = 'sigmoid') )
	if prep == 4 or prep == 7:
		autoencoder3.add( Conv1D(1, 1, activation = 'linear') )


	if data != 'data_humidity_together':
		autoencoder1.compile(optimizer='adam', loss = 'mse')
		autoencoder1.fit( X_train, X_train, epochs=500, verbose=0 )

	if data == 'data_humidity_seperate':
		autoencoder2.compile(optimizer='adam', loss = 'mse')
		autoencoder2.fit( X_train_humidity, X_train_humidity, epochs=500, verbose=0 )
		
	if data == 'data_humidity_together':
		print(X_train.shape)
		autoencoder3.compile(optimizer='adam', loss = 'mse')
		autoencoder3.fit( X_train, X_train, epochs=500, verbose=0 )
		

	encoder1 = Sequential()
	encoder1.add( Conv1D(16, 64, input_shape= (input_dim,1), weights = autoencoder1.layers[0].get_weights(), activation = 'relu'))
	encoder1.add(Flatten())

	encoder2 = Sequential()
	encoder2.add( Conv1D(16, 64, input_shape= (input_dim,1), weights = autoencoder2.layers[0].get_weights(), activation = 'relu'))
	encoder2.add(Flatten())

	encoder3 = Sequential()
	encoder3.add( Conv1D(32, 4, input_shape= (input_dim,1), weights = autoencoder3.layers[0].get_weights(), activation = 'relu'))
	encoder3.add(Flatten())

	if data == 'data_only':
		X_train_enc = encoder1.predict(X_train)
		X_test_enc = encoder1.predict(X_test)

	if data == 'data_humidity_seperate':
		X_train_enc = encoder1.predict(X_train)
		X_test_enc = encoder1.predict(X_test)

		X_train_humidity_enc = encoder2.predict(X_train_humidity)
		X_test_humidity_enc = encoder2.predict(X_test_humidity)

		X_train_enc = np.hstack((X_train_enc,X_train_humidity_enc))
		X_test_enc = np.hstack((X_test_enc,X_test_humidity_enc))

	if data == 'data_humidity_together':
		X_train_enc = encoder3.predict(X_train)
		X_test_enc = encoder3.predict(X_test)


	return X_train_enc, X_test_enc



# def PCA_transfom(X):

